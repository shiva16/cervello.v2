from flask import Flask, render_template, request
import nltk 
import numpy as np
from nltk import word_tokenize,sent_tokenize
#from gensim.models import Word2Vec
import xml.etree.ElementTree as ET
import pymongo
from pymongo import MongoClient
client = MongoClient()
db = client.corpustest
collection = db.corpus1
import pprint

app = Flask(__name__)

@app.route('/')
def student():
   return render_template('student.html')

@app.route('/result',methods = ['POST', 'GET'])
def result():
	if request.method == 'POST':
		result = request.form
		x=result['X']
		y=result['Y']
		print(db.corpus1.find_one())
	return render_template("result.html",result = result)

if __name__ == '__main__':
   app.run(debug = True)


